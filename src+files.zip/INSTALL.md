npm install react-router-dom
npm install axios
npm install @reduxjs/toolkit react-redux
npm install jwt-decode
npm install --save-dev vitest @testing-library/react
npm install react-hook-form
npm install -D @tailwindcss/postcss
npx shadcn@latest init
npm install -D @tailwindcss/forms
npm install framer-motion






ermal:
npm install react-hot-toast